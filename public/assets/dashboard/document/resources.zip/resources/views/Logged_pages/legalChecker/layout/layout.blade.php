<ul class="nav " role="" style="padding-top: 12px;">
    <li class="nav-item d-flex align-items-center active">
        <img src="{{asset('images/grid.png')}}" alt="">
        <a class="nav-link nav-itemz" href="{{url('user/term')}}" >Quoter</a>
    </li>
</ul>
